const btnAbrir = document.getElementById('mas');
const formulario = document.getElementById('formulario');
const btnCerrar = document.getElementById('cerrar');
const overlay = document.querySelector('.overlay');
const contenedorTareas = document.getElementById('contenedorTareas');
const alarmaAudio = document.getElementById('alarmaAudio');

let recordatorios = [];

//guardar recordatorios en localStorage
const guardarRecordatorios = () => {
    localStorage.setItem('recordatorios', JSON.stringify(recordatorios));
};

//cargar recordatorios desde localStorage
const cargarRecordatorios = () => {
    const recordatoriosGuardados = localStorage.getItem('recordatorios');
    if (recordatoriosGuardados) {
        recordatorios = JSON.parse(recordatoriosGuardados);

        recordatorios.forEach(recordatorio => {
            crearElementoTarea(recordatorio.texto, recordatorio.fecha, recordatorio.hora, recordatorio.completado);
        });
    }
};

const aplicarEstiloCompletado = (elementoTarea) => {
    elementoTarea.querySelector('h3').style.textDecoration = 'line-through';
    elementoTarea.querySelector('p:nth-of-type(1)').style.textDecoration = 'line-through';
    elementoTarea.querySelector('p:nth-of-type(2)').style.textDecoration = 'line-through';
    const botonHecha = elementoTarea.querySelector('.hecha');
    if (botonHecha) {
        botonHecha.style.display = 'none';
    }
    elementoTarea.classList.remove('tarea-alarmada');
};

// Mostrar popup
btnAbrir.addEventListener('click', () => {
    formulario.style.display = 'flex';
    overlay.style.display = 'block';
});

// Cerrar popup
btnCerrar.addEventListener('click', (e) => {
    e.stopPropagation();
    formulario.style.display = 'none';
    overlay.style.display = 'none';
});

overlay.addEventListener('click', () => {
    formulario.style.display = 'none';
    overlay.style.display = 'none';
});

// Función para crear el elemento HTML de la tarea
const crearElementoTarea = (texto, fecha, hora, completado = false) => {
    const nueva = document.createElement('div');
    nueva.className = 'tareas';
    nueva.innerHTML = `
    <div class="tarea">
        <h3>${texto}</h3>
        <p>Fecha: ${fecha}</p>
        <p>Hora: ${hora}</p>
        <div class="botones">
            <button class="hecha">Hecha</button>
            <button class="eliminar">Eliminar</button>
        </div>
    </div>
    `;

    if (completado) {
        aplicarEstiloCompletado(nueva)
    }

    // Añadir eventos a los botones de esta tarea específica
    nueva.querySelector('.hecha').addEventListener('click', () => {
        aplicarEstiloCompletado(nueva)

        const index = recordatorios.findIndex(r => r.texto === texto && r.fecha === fecha && r.hora === hora);
        if (index !== -1) {
            recordatorios[index].completado = true;
            guardarRecordatorios();
        }
    });

    nueva.querySelector('.eliminar').addEventListener('click', () => {
        nueva.remove();
        recordatorios = recordatorios.filter(r => !(r.texto === texto && r.fecha === fecha && r.hora === hora));
        guardarRecordatorios();
    });


    //eventos mouseover y mouseout
    nueva.addEventListener('mouseover', () => {
        nueva.style.transition = '0.3s';
    });

    nueva.addEventListener('mouseout', () => {
        nueva.style.transition = '0.3s';
    });

    contenedorTareas.appendChild(nueva);
};


const inputTarea = document.getElementById('tarea');
const inputFecha = document.getElementById('fecha');
const inputHora = document.getElementById('hora');
const botonEnviar = document.getElementById('enviar');

// Añadir evento keydown a los inputs del formulario
inputTarea.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        botonEnviar.click(); // simular un clic en el botón de enviar
    }
});

inputFecha.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        botonEnviar.click();
    }
});

inputHora.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        botonEnviar.click();
    }
});

// Crear tareas múltiples
const enviar = document.getElementById('enviar')
enviar.addEventListener('click', (e) => {
    e.preventDefault();

    const texto = document.getElementById('tarea').value;
    const fecha = document.getElementById('fecha').value;
    const hora = document.getElementById('hora').value;

    if (!texto || !fecha || !hora) {
        alert('Por favor, completa todos los campos para añadir un recordatorio.');
        return;
    }

    const nuevoRecordatorio = {
        texto,
        fecha,
        hora,
        completado: false
    };

    // Verificar si la tarea ya existe para evitar duplicados 
    const existe = recordatorios.some(r => r.texto === texto && r.fecha === fecha && r.hora === hora);
    if (existe) {
        alert('Este recordatorio ya existe.');
        return;
    }

    recordatorios.push(nuevoRecordatorio);
    guardarRecordatorios();

    crearElementoTarea(texto, fecha, hora);

    formulario.style.display = 'none';
    overlay.style.display = 'none';
    document.getElementById('tarea').value = '';
    document.getElementById('fecha').value = '';
    document.getElementById('hora').value = '';
});

// Función para verificar y activar alarmas
const verificarAlarmas = () => {
    const ahora = new Date();
    const hoy = ahora.toISOString().slice(0, 10);
    const horaActual = ahora.toTimeString().slice(0, 5);

    recordatorios.forEach((recordatorio, index) => {
        // solo activar si la tarea no ha sido completada y coincide la fecha y hora
        if (!recordatorio.completado && recordatorio.fecha === hoy && recordatorio.hora === horaActual) {
            alarmaAudio.play().catch(e => console.error("Error al reproducir el audio:", e));
            alert(`¡Es hora de: ${recordatorio.texto}!`);

            const tareaElemento = contenedorTareas.children[index];
            const tarjetaTarea = tareaElemento.querySelector('.tarea');
            if (tarjetaTarea) {
                tarjetaTarea.classList.add('tarea-alarmada');
                setTimeout(() => {
                    recordatorios[index].completado = true;
                    guardarRecordatorios();
                    aplicarEstiloCompletado(tareaElemento);
                }, 2000);
            }

        }
    });
};

// Cargar recordatorios 
document.addEventListener('DOMContentLoaded', cargarRecordatorios);

setInterval(verificarAlarmas, 30000);